# v1.0.6
- Foundry13 compatibility
- Add a bigger border to the chat message to help differentiate the types 
  
# v1.0.5
- Fix Dice So Nice Integration
 
# v1.0.4
- Support for Foundry V12
- Prevent the GM Dashboard from closing with the ESC key
- Fix the issue with Scars always rolling a d12
- Correct typos in the Whip Knight roll tables

# v1.0.3
- Add all 72 knights to the character generator
- Add all roll tables for Myths
- Update all Sparks tables
- Fix Dice So Nice! integration
- All tabs in the referee dashboard should follow the selected roll mode
- Add support for a roll flavor to specify a knight table (ex: [[/roll roling #table-knight-the-riddle-knight]])

# v1.0.2
- Add roll tables in the Referee Dashboard for Myths and extra tables. (Sky/Weather, Person, Holding, Land, Beast)
- Fix spelling for Fatigued and Armour.
- Correct typos in some compendium entries.

# v1.0.1
- Fix bonus dice being ignore when attacking
- Fix empty button on taking damage

# v1.0.0
- First release of the Mythic Bastionland System
